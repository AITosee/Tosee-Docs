#ifndef __SERIAL_H
#define __SERIAL_H

#ifdef __cpluscplus
extern "C" {
#endif

#include <stdio.h>

extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];

extern uint8_t Serial_RxRingbuffer[];

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

int Serial_Available(void);
int Serial_ReadArray(uint8_t *Array, uint16_t Length);

#ifdef __cpluscplus
}
#endif

#endif
