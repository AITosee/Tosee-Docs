#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Serial.h"
#include "Sentry.h"
#include <stdio.h>

#define VISION_TYPE Sentry2::kVisionCard

int main(void)
{
	Serial_Init();
	
	HwSentryUart::hw_uart_t uart_port = 1;
	Sentry2 sentry;
	sentry.begin(uart_port);
	sentry.VisionBegin(Sentry2::kVisionCard);
	
	while (1)
	{
		int obj_num = sentry.GetValue(VISION_TYPE, kStatus);
		
    for (int i = 1; i <= obj_num; ++i) {
      int x = sentry.GetValue(VISION_TYPE, kXValue, i);
      int y = sentry.GetValue(VISION_TYPE, kYValue, i);
      int w = sentry.GetValue(VISION_TYPE, kWidthValue, i);
      int h = sentry.GetValue(VISION_TYPE, kHeightValue, i);
      int l = sentry.GetValue(VISION_TYPE, kLabel, i);
		}
	}
}
